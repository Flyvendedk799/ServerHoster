// sh-app.jsx — Icons, shared UI, Sidebar. Exports to window.

// ── Icon component ─────────────────────────────────────────
function Ic({ name, size = 16, className, style }) {
  const svgProps = {
    width: size, height: size,
    viewBox: "0 0 24 24", fill: "none",
    stroke: "currentColor", strokeWidth: "1.75",
    strokeLinecap: "round", strokeLinejoin: "round",
    className, style, "aria-hidden": "true"
  };
  const paths = {
    dashboard:   <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></>,
    server:      <><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><circle cx="6" cy="6" r=".6" fill="currentColor" stroke="none"/><circle cx="6" cy="18" r=".6" fill="currentColor" stroke="none"/></>,
    folder:      <><path d="M4 20h16a2 2 0 002-2V8a2 2 0 00-2-2h-7.93a2 2 0 01-1.66-.9l-.82-1.2A2 2 0 008.07 3H4a2 2 0 00-2 2v13c0 1.1.9 2 2 2z"/><line x1="8" y1="10" x2="8" y2="14"/><line x1="12" y1="10" x2="12" y2="12"/><line x1="16" y1="10" x2="16" y2="16"/></>,
    database:    <><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></>,
    activity:    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>,
    terminal:    <><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></>,
    bell:        <><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></>,
    settings:    <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></>,
    sun:         <><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></>,
    moon:        <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>,
    logout:      <><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></>,
    chevL:       <polyline points="15 18 9 12 15 6"/>,
    chevR:       <polyline points="9 18 15 12 9 6"/>,
    git:         <><line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 01-9 9"/></>,
    play:        <polygon points="5 3 19 12 5 21 5 3"/>,
    zap:         <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>,
    layers:      <><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></>,
    arrowUR:     <><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></>,
    extLink:     <><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></>,
    search:      <><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></>,
    loader:      <path d="M21 12a9 9 0 11-6.219-8.56"/>,
    alertT:      <><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></>,
    globe:       <><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></>,
    rotate:      <><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></>,
    stop:        <rect x="3" y="3" width="18" height="18" rx="2"/>,
    plus:        <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>,
    lock:        <><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></>,
    user:        <><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></>,
    signin:      <><path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></>,
    cpu:         <><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M1 9h3M1 15h3M20 9h3M20 15h3"/></>,
    hdd:         <><line x1="22" y1="12" x2="2" y2="12"/><path d="M5.45 5.11L2 12v6a2 2 0 002 2h16a2 2 0 002-2v-6l-3.45-6.89A2 2 0 0016.76 4H7.24a2 2 0 00-1.79 1.11z"/><circle cx="6" cy="16" r=".6" fill="currentColor" stroke="none"/><circle cx="10" cy="16" r=".6" fill="currentColor" stroke="none"/></>,
    rocket:      <><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 00-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 012-3.95A12.88 12.88 0 0122 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 01-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></>,
    shield:      <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></>,
    checkCircle: <><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></>,
    xCircle:     <><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></>,
    clock:       <><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></>,
    copy:        <><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></>,
    filter:      <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>,
    box:         <><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></>,
    key:         <><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></>,
    download:    <><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></>,
  };
  return <svg {...svgProps}>{paths[name] || null}</svg>;
}

// ── Status helpers ─────────────────────────────────────────
function StatusDot({ status }) {
  const s = status?.toLowerCase();
  const cls = s === 'running' ? 'sdot sdot-green'
    : (s === 'error' || s === 'crashed' || s === 'failed') ? 'sdot sdot-red'
    : (s === 'building' || s === 'starting' || s === 'stopping') ? 'sdot sdot-amber'
    : 'sdot';
  return <span className={cls} />;
}

function StatusBadge({ status }) {
  const s = status?.toLowerCase();
  const cls = s === 'running' ? 'status-badge status-running'
    : (s === 'error' || s === 'crashed' || s === 'failed') ? 'status-badge status-error'
    : (s === 'building' || s === 'starting' || s === 'stopping') ? 'status-badge status-building'
    : 'status-badge status-stopped';
  return <span className={cls}><StatusDot status={status} />{s}</span>;
}

function Tag({ children, color }) {
  return <span className={color ? `tag tag-${color}` : 'tag'}>{children}</span>;
}

function Progress({ value, color }) {
  const c = value >= 85 ? 'red' : value >= 70 ? 'amber' : (color || 'blue');
  return (
    <div className="progress">
      <div className={`pb pb-${c}`} style={{ width: `${Math.min(value, 100)}%` }} />
    </div>
  );
}

// ── Sidebar ────────────────────────────────────────────────
function Sidebar({ page, setPage, collapsed, setCollapsed, theme, toggleTheme }) {
  const NAV = [
    { id: 'dashboard',     label: 'Dashboard',    icon: 'dashboard' },
    { id: 'services',      label: 'Services',     icon: 'server',   badge: '5' },
    { id: 'projects',      label: 'Projects',     icon: 'folder' },
    { id: 'databases',     label: 'Databases',    icon: 'database' },
    { id: 'proxy',         label: 'Edge Ingress', icon: 'activity' },
    { id: 'deployments',   label: 'Deployments',  icon: 'terminal' },
    { id: 'notifications', label: 'Alerts',       icon: 'bell',     badge: '2', badgeDanger: true },
    { id: 'settings',      label: 'Settings',     icon: 'settings' },
  ];

  return (
    <aside className="sidebar">
      <div className="sb-head">
        <div className="sb-logo">LS</div>
        {!collapsed && (
          <div className="fcol" style={{ gap: 0, minWidth: 0 }}>
            <span className="sb-name">LocalSURV</span>
            <span className="sb-sub">Control Plane</span>
          </div>
        )}
        <button className="sb-toggle" onClick={() => setCollapsed(c => !c)}
                title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}>
          <Ic name={collapsed ? 'chevR' : 'chevL'} size={11} />
        </button>
      </div>

      <nav className="sb-nav">
        {NAV.map(item => (
          <button key={item.id}
                  className={`nav-item${page === item.id ? ' active' : ''}`}
                  onClick={() => setPage(item.id)}
                  title={collapsed ? item.label : undefined}>
            <Ic name={item.icon} size={16} />
            {!collapsed && <span>{item.label}</span>}
            {!collapsed && item.badge && (
              <span className={`nav-badge${item.badgeDanger ? ' danger' : ''}`}>{item.badge}</span>
            )}
          </button>
        ))}
      </nav>

      <div className="sb-footer">
        <button className="nav-item" onClick={toggleTheme}
                title={theme === 'dark' ? 'Light mode' : 'Dark mode'}>
          <Ic name={theme === 'dark' ? 'sun' : 'moon'} size={16} />
          {!collapsed && <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>}
        </button>
        <button className="nav-item" onClick={() => setPage('login')} title="Sign out">
          <Ic name="logout" size={16} />
          {!collapsed && <span>Sign Out</span>}
        </button>
      </div>
    </aside>
  );
}

Object.assign(window, { Ic, StatusDot, StatusBadge, Tag, Progress, Sidebar });
