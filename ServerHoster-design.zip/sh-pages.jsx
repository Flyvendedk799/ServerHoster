// sh-pages.jsx — All page components. Exports to window.

// ── Mock data ──────────────────────────────────────────────
const SERVICES = [
  { id:'s1', name:'api-server',          type:'node',   status:'running',  domain:'api.myapp.com',     port:3000, project:'myapp',     env:'production', commit:'a4f8b3c', ago:'2h ago',  branch:'main',       cpu:14, mem:248 },
  { id:'s2', name:'web-frontend',        type:'node',   status:'running',  domain:'myapp.com',         port:5173, project:'myapp',     env:'production', commit:'b9e2d1f', ago:'2h ago',  branch:'main',       cpu:4,  mem:91  },
  { id:'s3', name:'queue-worker',        type:'node',   status:'stopped',  domain:null,                port:4000, project:'myapp',     env:'production', commit:null,      ago:'—',       branch:'main',       cpu:0,  mem:0   },
  { id:'s4', name:'staging-api',         type:'node',   status:'running',  domain:'staging.myapp.com', port:3001, project:'staging',   env:'staging',    commit:'c7a3e9b', ago:'5h ago',  branch:'develop',    cpu:6,  mem:118 },
  { id:'s5', name:'ml-inference',        type:'python', status:'error',    domain:null,                port:8000, project:'ml-core',   env:'production', commit:'d2f1c4a', ago:'1d ago',  branch:'main',       cpu:0,  mem:0   },
  { id:'s6', name:'analytics-pipeline', type:'python', status:'building', domain:null,                port:9000, project:'analytics', env:'production', commit:'e8b7d6c', ago:'8m ago',  branch:'feature/v2', cpu:0,  mem:0   },
];

const DEPLOYMENTS = [
  { id:'d1', svc:'api-server',          status:'success',  commit:'a4f8b3c', msg:'feat: add user authentication',      branch:'main',       ago:'2h ago', dur:'1m 42s' },
  { id:'d2', svc:'web-frontend',        status:'success',  commit:'b9e2d1f', msg:'fix: resolve hydration mismatch',   branch:'main',       ago:'2h ago', dur:'58s'    },
  { id:'d3', svc:'analytics-pipeline', status:'building', commit:'e8b7d6c', msg:'feat: new ML pipeline integration',  branch:'feature/v2', ago:'8m ago', dur:'—'      },
  { id:'d4', svc:'ml-inference',        status:'failed',   commit:'d2f1c4a', msg:'refactor: update CUDA dependencies',branch:'main',       ago:'1d ago', dur:'3m 12s' },
  { id:'d5', svc:'staging-api',         status:'success',  commit:'c7a3e9b', msg:'feat: implement rate limiting',     branch:'develop',    ago:'5h ago', dur:'1m 8s'  },
  { id:'d6', svc:'api-server',          status:'success',  commit:'f3c9a8e', msg:'chore: update dependencies',       branch:'main',       ago:'1d ago', dur:'1m 55s' },
];

const DATABASES = [
  { id:'db1', name:'myapp-postgres',   engine:'postgres', status:'running', port:5432,  project:'myapp',     size:'2.4 GB', conns:8  },
  { id:'db2', name:'redis-cache',      engine:'redis',    status:'running', port:6379,  project:'myapp',     size:'128 MB', conns:14 },
  { id:'db3', name:'staging-postgres', engine:'postgres', status:'running', port:5433,  project:'staging',   size:'340 MB', conns:2  },
  { id:'db4', name:'analytics-mongo',  engine:'mongo',    status:'stopped', port:27017, project:'analytics', size:'1.1 GB', conns:0  },
];

const HEALTH = {
  score: 87, memPct: 75, diskPct: 74, diskFree: '118 GB',
  loadAvg: 2.4, platform: 'darwin', cpus: 8, totalMem: '16 GB',
  warnings: ['Memory usage is above the 70% threshold'],
};

const runningCount = SERVICES.filter(s => s.status === 'running').length;

// ── Login ──────────────────────────────────────────────────
function LoginPage({ onLogin }) {
  const [user, setUser] = React.useState('');
  const [pass, setPass] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  function submit(e) {
    e.preventDefault();
    if (!pass) return;
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin(); }, 900);
  }

  return (
    <div className="auth-screen animate-up">
      <div className="auth-card">
        <div className="auth-logo-wrap">
          <div className="auth-logo">LS</div>
          <span className="auth-product">LocalSURV</span>
        </div>
        <div className="auth-title">Sign in</div>
        <div className="auth-sub">Access your infrastructure control plane</div>
        <form className="auth-form" onSubmit={submit}>
          <div className="field">
            <label className="field-label">Username</label>
            <div className="input-wrap">
              <span className="input-icon"><Ic name="user" size={14} /></span>
              <input className="input" type="text" value={user} onChange={e => setUser(e.target.value)}
                     placeholder="admin" autoFocus autoComplete="username" />
            </div>
            <span className="field-hint">Leave blank to use legacy passphrase</span>
          </div>
          <div className="field">
            <label className="field-label">Password</label>
            <div className="input-wrap">
              <span className="input-icon"><Ic name="lock" size={14} /></span>
              <input className="input" type="password" value={pass} onChange={e => setPass(e.target.value)}
                     placeholder="••••••••" required autoComplete="current-password" />
            </div>
          </div>
          <button type="submit" className="btn btn-primary btn-lg"
                  style={{ width: '100%', justifyContent: 'center', marginTop: 4 }}
                  disabled={loading}>
            {loading
              ? <Ic name="loader" size={16} className="spinner" />
              : <><Ic name="signin" size={15} />Sign In</>}
          </button>
        </form>
        <div className="auth-footer">
          <Ic name="shield" size={13} style={{ color: 'var(--green)', opacity: .8 }} />
          <span>Secure session management active</span>
        </div>
      </div>
    </div>
  );
}

// ── Dashboard ──────────────────────────────────────────────
function DashboardPage({ setPage }) {
  const scoreColor = HEALTH.score >= 80 ? 'var(--green)' : HEALTH.score >= 60 ? 'var(--amber)' : 'var(--red)';

  return (
    <div className="page animate-up">
      <div className="page-hd">
        <div>
          <div className="page-title">Overview</div>
          <div className="page-desc flex items-center gap-2" style={{ marginTop: 3 }}>
            <span className="sdot sdot-green" style={{ width: 6, height: 6 }} />
            <span>Real-time streaming active · {HEALTH.platform} · {HEALTH.cpus} vCPUs · load {HEALTH.loadAvg}</span>
          </div>
        </div>
        <div className="page-hd-actions">
          <button className="btn btn-default" onClick={() => setPage('deployments')}>
            <Ic name="terminal" size={14} />View Deployments
          </button>
          <button className="btn btn-primary" onClick={() => setPage('services')}>
            <Ic name="rocket" size={14} />Deploy New
          </button>
        </div>
      </div>

      {/* Metric tiles */}
      <div className="metrics-row">
        <div className="card metric-card">
          <div className="metric-lbl">Services Running</div>
          <div className="metric-val">{runningCount}<span className="unit"> / {SERVICES.length}</span></div>
          <div className="metric-sub">{SERVICES.length - runningCount} idle or error</div>
          <Progress value={(runningCount / SERVICES.length) * 100} color="green" />
        </div>
        <div className="card metric-card">
          <div className="metric-lbl">Health Score</div>
          <div className="metric-val" style={{ color: scoreColor }}>{HEALTH.score}<span className="unit">%</span></div>
          <div className="metric-sub">{HEALTH.warnings.length ? `${HEALTH.warnings.length} active alert` : 'All systems nominal'}</div>
          <Progress value={HEALTH.score} color="green" />
        </div>
        <div className="card metric-card">
          <div className="metric-lbl">Memory Usage</div>
          <div className="metric-val">{HEALTH.memPct}<span className="unit">%</span></div>
          <div className="metric-sub">{Math.round(16 * HEALTH.memPct / 100 * 10) / 10} GB of {HEALTH.totalMem} used</div>
          <Progress value={HEALTH.memPct} />
        </div>
        <div className="card metric-card">
          <div className="metric-lbl">Disk Usage</div>
          <div className="metric-val">{HEALTH.diskPct}<span className="unit">%</span></div>
          <div className="metric-sub">{HEALTH.diskFree} free on /</div>
          <Progress value={HEALTH.diskPct} />
        </div>
      </div>

      {/* Alert banner */}
      {HEALTH.warnings.length > 0 && (
        <div className="alert alert-amber">
          <Ic name="alertT" size={15} style={{ color: 'var(--amber)', flexShrink: 0, marginTop: 1 }} />
          <div style={{ flex: 1 }}>
            <div className="alert-title">Maintenance Alert</div>
            <div className="text-sm muted">{HEALTH.warnings[0]}</div>
          </div>
          <button className="btn btn-sm btn-default" style={{ flexShrink: 0 }}>View Logs</button>
        </div>
      )}

      {/* Two-panel grid */}
      <div className="grid-2">
        <div className="card">
          <div className="card-head">
            <span className="card-title">Recent Deployments</span>
            <button className="card-link" onClick={() => setPage('deployments')}>
              View all <Ic name="arrowUR" size={12} />
            </button>
          </div>
          {DEPLOYMENTS.slice(0, 5).map(dep => (
            <div key={dep.id} className="list-row">
              <StatusDot status={dep.status === 'failed' ? 'error' : dep.status} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="fw500 truncate" style={{ fontSize: 13 }}>{dep.svc}</div>
                <div className="text-xs muted truncate" style={{ marginTop: 1 }}>{dep.msg}</div>
              </div>
              <div className="fcol items-end gap-1" style={{ flexShrink: 0 }}>
                <span className="hash">{dep.commit}</span>
                <span className="text-xs dimmed">{dep.ago}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="card">
          <div className="card-head">
            <span className="card-title">Service Health</span>
            <button className="card-link" onClick={() => setPage('services')}>
              Manage <Ic name="arrowUR" size={12} />
            </button>
          </div>
          {SERVICES.map(svc => (
            <div key={svc.id} className="list-row">
              <StatusDot status={svc.status} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="fw500 truncate" style={{ fontSize: 13 }}>{svc.name}</div>
                <div className="text-xs muted truncate" style={{ marginTop: 1 }}>
                  {svc.domain || `localhost:${svc.port}`}
                </div>
              </div>
              <div className="flex items-center gap-3 text-xs muted" style={{ flexShrink: 0 }}>
                {svc.status === 'running' && svc.cpu > 0
                  ? <><span className="flex items-center gap-1"><Ic name="cpu" size={11} />{svc.cpu}%</span>
                       <span className="flex items-center gap-1"><Ic name="hdd" size={11} />{svc.mem}MB</span></>
                  : <span>—</span>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Services ───────────────────────────────────────────────
function ServicesPage() {
  const [search, setSearch] = React.useState('');
  const [envFilter, setEnvFilter] = React.useState('all');

  const filtered = SERVICES.filter(s => {
    const matchEnv = envFilter === 'all' || s.env === envFilter;
    const matchQ   = !search || s.name.toLowerCase().includes(search.toLowerCase());
    return matchEnv && matchQ;
  });

  return (
    <div className="page animate-up">
      <div className="page-hd">
        <div>
          <div className="page-title">Services</div>
          <div className="page-desc">Manage apps, workers, and container services</div>
        </div>
        <div className="page-hd-actions">
          <div className="input-wrap" style={{ width: 200 }}>
            <span className="input-icon"><Ic name="search" size={13} /></span>
            <input className="input" style={{ height: 30, fontSize: 12.5 }}
                   value={search} onChange={e => setSearch(e.target.value)}
                   placeholder="Filter services…" />
          </div>
          <div className="flex" style={{
            background: 'var(--s2)', borderRadius: 'var(--r2)',
            border: '1px solid var(--b1)', overflow: 'hidden'
          }}>
            {['all','production','staging'].map(env => (
              <button key={env} className="btn btn-sm" onClick={() => setEnvFilter(env)}
                      style={{
                        borderRadius: 0, border: 'none', height: 30,
                        background: envFilter === env ? 'var(--b2)' : 'transparent',
                        color: envFilter === env ? 'var(--t1)' : 'var(--t2)',
                        fontWeight: envFilter === env ? 600 : 400
                      }}>
                {env === 'all' ? 'All' : env.charAt(0).toUpperCase() + env.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Quick-launch cards */}
      <div className="act-grid">
        {[
          { icon:'git',    label:'GitHub Deploy',    desc:'Auto-deploy from any branch',        featured: true },
          { icon:'layers', label:'Import Stack',     desc:'Provision via Docker Compose YAML',  color:'cyan' },
          { icon:'zap',    label:'Platform Presets', desc:'Start from a tuned configuration',   color:'amber' },
          { icon:'play',   label:'Quick Launch',     desc:'Zero-config local deployment',       color:'green' },
        ].map(({ icon, label, desc, featured, color }) => (
          <div key={label} className={`act-card${featured ? ' featured' : ''}`}>
            <div className="act-icon" style={!featured && color ? { color: `var(--${color})` } : {}}>
              <Ic name={icon} size={17} />
            </div>
            <div className="act-card-title">{label}</div>
            <div className="act-card-desc">{desc}</div>
          </div>
        ))}
      </div>

      {/* Service list */}
      <div>
        <div className="flex items-center gap-2" style={{ marginBottom: 10 }}>
          <span className="fw600" style={{ fontSize: 13 }}>Application Stacks</span>
          <Tag color="blue">{filtered.length} services</Tag>
        </div>
        <div className="svc-list">
          {filtered.map(svc => (
            <div key={svc.id} className="svc-row">
              <StatusDot status={svc.status} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="svc-name">{svc.name}</span>
                  <Tag>{svc.type}</Tag>
                  {svc.env !== 'production' && <Tag color="amber">{svc.env}</Tag>}
                </div>
                <div className="svc-meta">
                  <Ic name={svc.domain ? 'globe' : 'terminal'} size={11} style={{ flexShrink: 0 }} />
                  <span>{svc.domain || `localhost:${svc.port}`}</span>
                  {svc.commit && (
                    <><span className="dimmed">·</span>
                    <Ic name="git" size={11} style={{ flexShrink: 0 }} />
                    <span style={{ fontFamily: 'var(--mono)', fontSize: 11 }}>{svc.commit}</span>
                    <span className="dimmed">·</span>
                    <span>{svc.ago}</span></>
                  )}
                </div>
              </div>
              <StatusBadge status={svc.status} />
              <div className="svc-actions">
                {svc.status === 'running'
                  ? <button className="btn btn-sm btn-ghost btn-icon" title="Stop"><Ic name="stop" size={13} /></button>
                  : <button className="btn btn-sm btn-ghost btn-icon" title="Start"><Ic name="play" size={13} /></button>}
                <button className="btn btn-sm btn-ghost btn-icon" title="Restart"><Ic name="rotate" size={13} /></button>
                <button className="btn btn-sm btn-default">Logs</button>
                <button className="btn btn-sm btn-ghost btn-icon" title="Settings"><Ic name="settings" size={13} /></button>
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="card" style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--t3)' }}>
              No services match your filter.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Deployments ────────────────────────────────────────────
function DeploymentsPage() {
  return (
    <div className="page animate-up">
      <div className="page-hd">
        <div>
          <div className="page-title">Deployments</div>
          <div className="page-desc">CI/CD pipeline history across all services</div>
        </div>
      </div>
      <div className="card">
        <div className="card-head">
          <span className="card-title">Deployment Log</span>
          <Tag color="blue">{DEPLOYMENTS.length} entries</Tag>
        </div>
        {DEPLOYMENTS.map(dep => (
          <div key={dep.id} className="list-row">
            <StatusDot status={dep.status === 'failed' ? 'error' : dep.status} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="flex items-center gap-2">
                <span className="fw500 truncate" style={{ fontSize: 13 }}>{dep.svc}</span>
                <Tag>{dep.branch}</Tag>
              </div>
              <div className="text-xs muted truncate" style={{ marginTop: 2 }}>{dep.msg}</div>
            </div>
            <div className="flex items-center gap-3 text-xs muted" style={{ flexShrink: 0 }}>
              <span className="hash">{dep.commit}</span>
              <span>{dep.dur}</span>
              <span className="dimmed">{dep.ago}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Databases ──────────────────────────────────────────────
function DatabasesPage() {
  return (
    <div className="page animate-up">
      <div className="page-hd">
        <div>
          <div className="page-title">Databases</div>
          <div className="page-desc">Managed database instances and containers</div>
        </div>
        <div className="page-hd-actions">
          <button className="btn btn-primary"><Ic name="plus" size={14} />New Database</button>
        </div>
      </div>
      <div className="card">
        <div className="card-head">
          <span className="card-title">All Databases</span>
          <Tag color="blue">{DATABASES.length} instances</Tag>
        </div>
        {DATABASES.map(db => (
          <div key={db.id} className="list-row">
            <StatusDot status={db.status} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="flex items-center gap-2">
                <span className="fw500" style={{ fontSize: 13 }}>{db.name}</span>
                <Tag>{db.engine}</Tag>
                <Tag>{db.project}</Tag>
              </div>
              <div className="text-xs muted flex items-center gap-2" style={{ marginTop: 2 }}>
                <span>Port {db.port}</span>
                <span className="dimmed">·</span>
                <span>{db.size}</span>
                <span className="dimmed">·</span>
                <span>{db.conns} connections</span>
              </div>
            </div>
            <StatusBadge status={db.status} />
            <div className="flex gap-2">
              <button className="btn btn-sm btn-default">
                <Ic name="copy" size={12} />Connection string
              </button>
              <button className="btn btn-sm btn-ghost btn-icon" title="Settings">
                <Ic name="settings" size={13} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Settings ───────────────────────────────────────────────
function SettingsPage() {
  const [tab, setTab] = React.useState('connectivity');
  const TABS = ['connectivity', 'integrations', 'data', 'system'];

  return (
    <div className="page animate-up">
      <div className="page-hd">
        <div>
          <div className="page-title">Settings</div>
          <div className="page-desc">Configure routing, integrations, and system preferences</div>
        </div>
      </div>

      <div className="flex gap-1" style={{
        background: 'var(--s1)', border: '1px solid var(--b1)',
        borderRadius: 'var(--r3)', padding: '3px', width: 'fit-content'
      }}>
        {TABS.map(t => (
          <button key={t} className="btn btn-sm" onClick={() => setTab(t)}
                  style={{
                    textTransform: 'capitalize',
                    background: tab === t ? 'var(--s3)' : 'transparent',
                    border: '1px solid ' + (tab === t ? 'var(--b2)' : 'transparent'),
                    color: tab === t ? 'var(--t1)' : 'var(--t2)',
                  }}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'connectivity' && (
        <div className="fcol gap-3">
          <div className="card">
            <div className="card-head">
              <div>
                <div className="card-title flex items-center gap-2">
                  <Ic name="globe" size={14} />Cloudflare Tunnel
                </div>
                <div className="text-xs muted" style={{ marginTop: 3 }}>
                  Route public traffic to local services without opening ports
                </div>
              </div>
              <StatusBadge status="stopped" />
            </div>
            <div style={{ padding: '16px 18px' }} className="fcol gap-3">
              <div className="grid-2">
                <div className="field"><label className="field-label">Account ID</label>
                  <input className="input" placeholder="abc123def456…" /></div>
                <div className="field"><label className="field-label">Tunnel ID</label>
                  <input className="input" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" /></div>
              </div>
              <div className="flex gap-2">
                <button className="btn btn-primary btn-sm"><Ic name="play" size={12} />Start Tunnel</button>
                <button className="btn btn-default btn-sm">Save Config</button>
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-head">
              <div>
                <div className="card-title flex items-center gap-2">
                  <Ic name="shield" size={14} />SSL Certificates
                </div>
                <div className="text-xs muted" style={{ marginTop: 3 }}>
                  Let's Encrypt via HTTP-01 or DNS-01 challenge
                </div>
              </div>
              <Tag color="green">Auto-renew on</Tag>
            </div>
            <div style={{ padding: '16px 18px' }} className="fcol gap-3">
              <div className="field"><label className="field-label">Challenge Mode</label>
                <div className="flex gap-2">
                  {['HTTP-01', 'DNS-01'].map(m => (
                    <button key={m} className="btn btn-sm btn-default"
                            style={{ fontFamily: 'var(--mono)', fontSize: 11 }}>{m}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'integrations' && (
        <div className="card">
          <div className="card-head">
            <div className="card-title flex items-center gap-2">
              <Ic name="git" size={14} />GitHub Integration
            </div>
          </div>
          <div style={{ padding: '16px 18px' }} className="fcol gap-3">
            <div className="flex items-center gap-3 text-sm muted">
              <Ic name="checkCircle" size={14} style={{ color: 'var(--green)' }} />
              <span>Personal Access Token configured</span>
            </div>
            <div className="field"><label className="field-label">Webhook URL</label>
              <div className="flex gap-2">
                <input className="input" value="https://yourdomain.com/webhooks/github" readOnly />
                <button className="btn btn-default btn-sm"><Ic name="copy" size={12} /></button>
              </div>
            </div>
            <div className="field"><label className="field-label">Rotate Token</label>
              <div className="flex gap-2">
                <input className="input" placeholder="ghp_••••••••••••••••••••••••••••••••" />
                <button className="btn btn-primary btn-sm">Update</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {(tab === 'data' || tab === 'system') && (
        <div className="card" style={{ padding: '56px 24px', textAlign: 'center' }}>
          <Ic name="settings" size={28} style={{ color: 'var(--t3)', opacity: .4, marginBottom: 12 }} />
          <div className="fw600" style={{ fontSize: 13, color: 'var(--t2)', textTransform: 'capitalize' }}>
            {tab} settings
          </div>
          <div className="text-sm muted" style={{ marginTop: 4 }}>
            Available in the full application
          </div>
        </div>
      )}
    </div>
  );
}

// ── Stub pages ─────────────────────────────────────────────
function StubPage({ title, icon, desc }) {
  return (
    <div className="page animate-up">
      <div className="page-hd">
        <div>
          <div className="page-title">{title}</div>
          {desc && <div className="page-desc">{desc}</div>}
        </div>
      </div>
      <div className="card" style={{ padding: '72px 24px', textAlign: 'center' }}>
        <Ic name={icon} size={32} style={{ color: 'var(--t3)', opacity: .35, marginBottom: 14 }} />
        <div className="fw600" style={{ fontSize: 13.5, color: 'var(--t2)' }}>No data yet</div>
        <div className="text-sm muted" style={{ marginTop: 5 }}>
          Content will appear once the server is running
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  LoginPage, DashboardPage, ServicesPage, DeploymentsPage,
  DatabasesPage, SettingsPage, StubPage,
});
